package com.pack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcDataJpaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
